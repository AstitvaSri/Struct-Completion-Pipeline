# StructCompletion

Image Completion using Planar Structure Guidance

This is a python re-implementation(translation of the matlab code) of the paper.

> Jia-Bin Huang, Sing Bing Kang, Narendra Ahuja, and Johannes Kopf, Image Completion using Planar Structure Guidance, ACM Transactions on Graphics (Proceedings of SIGGRAPH 2014), 33(4), 2014

# Requirments

opencv3.2 with contrib(https://pypi.python.org/pypi/opencv-contrib-python)

* it brings a bug

python 3.5

# Origin

https://github.com/jbhuang0604/StructCompletion/issues/new