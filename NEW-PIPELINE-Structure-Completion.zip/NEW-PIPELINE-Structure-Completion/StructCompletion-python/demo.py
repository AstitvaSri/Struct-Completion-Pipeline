import time
import cv2
import os
import numpy as np

from init_opt import optA, optS
from source.extract.extract_planar_structure import extract_planar_structure
from source.pyramid.create_pyramid import create_pyramid
from source.pyramid.planar_structure_pyramid import planar_structure_pyramid
from source.synthesis.synthesis import synthesis

if __name__ == "__main__":
    
    input_res = (362,487)
    files = os.listdir('data')
    
    invalid = []
    times = []
    
    for filename in files:
        try:
            image_name = filename
            print("************************************************************************")
            print(image_name)
            print("************************************************************************")
            
            print('- Extract planar structures')
            time0 = time.time()
            img, mask, maskD, modelPlane, modelReg = extract_planar_structure(image_name, optA)
            print('Done in %6.3f seconds.\n' % (time.time() - time0))

            print('- Construct image pyramid')
            time1 = time.time()
            imgPyr, maskPyr, scaleImgPyr = create_pyramid(img, maskD, optS)

            modelPlane, modelReg = planar_structure_pyramid(scaleImgPyr, modelPlane, modelReg)
            print('Done in %6.3f seconds.\n' % (time.time() - time1))

            # Completion by synthesis
            time2 = time.time()
            print('- Image completion using planar structure guidance')
            imgPyr = synthesis(imgPyr, maskPyr, modelPlane, modelReg, optS,image_name, input_res)
            print('Synthesis took %6.3f seconds.\n' % (time.time() - time2))

            imgSyn = imgPyr[0]
            times.append(time.time()-time0)

        except:
        	invalid.append(image_name)
    
    np.save('times.npy',np.array(times))
    print("INVALID VANISHING POINTS ---> ",invalid)
         
