import cv2
import numpy as np
import os
from tqdm import tqdm

dataroot = '../tshirt_data'
saveroot = dataroot + '/masked_images'

images = os.listdir(dataroot+'/images')
masks = os.listdir(dataroot+'/masks')

top, bottom, left, right = 13, 500, 75, 437

os.mkdir(saveroot)
common_mask = cv2.imread('common_front_panel_mask.png',0)
for idx in tqdm(range(len(images))):
    imname = images[idx]
    maskname = masks[idx]
    im = cv2.imread(dataroot+'/images/'+imname)
    mask = cv2.imread(dataroot+'/masks/'+maskname,0)
    mask[common_mask==0] = 0
    im_alpha = np.uint8(np.zeros((im.shape[0],im.shape[1],4)))
    im_alpha[mask!=0] = [255,255,255,255]
    im_alpha[:,:,:3] = im
    im_alpha[mask==0] = [0,0,0,0]
    im_alpha = im_alpha[top:bottom,left:right]
    cv2.imwrite(saveroot+'/'+imname,im_alpha)
