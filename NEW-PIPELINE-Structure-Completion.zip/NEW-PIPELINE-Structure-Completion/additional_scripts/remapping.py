import cv2
import numpy as np
import os
from tqdm import tqdm

dataroot = '../StructCompletion-python/result/'
saveroot = '../tshirt_data/remapped/'
os.mkdir(saveroot)

images = os.listdir(dataroot)
common_mask = cv2.imread('common_front_panel_mask.png',0)

top, bottom, left, right = 13, 500, 75, 437

for image in tqdm(images):
    im = cv2.imread(dataroot+image)
    remapped = np.uint8(np.zeros((common_mask.shape[0],common_mask.shape[1],3)))
    remapped[top:bottom,left:right] = im[:,:,:3]
    remapped[common_mask==0] = [0,0,0]
    cv2.imwrite(saveroot+image[:-4]+'_remapped.png',np.uint8(remapped))
